# Aurora Relay — Frontend Design Direction

## Three possible directions

### Theme Name: Aurora Relay
Very dark graphite command-center UI with cyan signal lines, saffron highlights, and editorial paper textures. The mood is calm, precise, and quietly intelligent.
Probability: 0.07

### Theme Name: Field Notes
Warm ivory research notebook interface with graphite typography, blue annotations, and modular index-card task views. The mood is tactile, thoughtful, and exploratory.
Probability: 0.04

### Theme Name: Glass Circuit
A cool, translucent operations console with slate panels, restrained cyan illumination, and layered data surfaces. The mood is technical, focused, and high-trust.
Probability: 0.02

## Chosen approach: Aurora Relay

### Design Movement
Contemporary editorial Swiss modernism fused with instrument-panel information design: generous margins, disciplined asymmetry, sharp typographic hierarchy, and small moments of signal color.

### Core Principles
1. Treat the dashboard like a working desk, not a marketing page: every surface should support a decision or an action.
2. Use asymmetry and editorial rhythm to create hierarchy instead of repetitive centered cards.
3. Use cyan for active intelligence, saffron for human attention, and ivory text only where contrast is guaranteed.
4. Keep motion purposeful: signal pulses, status transitions, and gentle panel reveals; never decorative motion for its own sake.

### Color Philosophy
Graphite-black creates focus and reduces visual noise. Electric cyan means the system is active and connected. Saffron marks human judgment, approvals, and attention. Ivory provides a warm counterweight so the product feels crafted rather than sterile.

### Layout Paradigm
A persistent left rail establishes orientation. The main workspace uses a wide editorial header, a primary task composer, and a split lower field: active work on the left, system intelligence on the right. Dense information is staged in horizontal bands rather than uniform card grids.

### Signature Elements
- A cyan signal rail that appears beside active tasks and live events.
- Small saffron approval flags for moments that need human judgment.
- Hairline contour textures and offset labels that make the interface feel like an instrument panel built on paper.

### Interaction Philosophy
Interactions should feel like operating a precise instrument: direct, reversible, and legible. Hover reveals context; clicks produce immediate visual acknowledgement; destructive or consequential actions are explicit. Empty states teach the next move instead of apologizing.

### Animation
Use 160–240ms ease-out transitions for controls and panel states. Live events should enter with a short opacity/translate reveal and a single cyan pulse. Use CSS transform and opacity only. Respect prefers-reduced-motion and remove nonessential pulses when requested.

### Typography System
Use Space Grotesk for display and interface headings, paired with IBM Plex Mono for labels, timestamps, tool names, and metadata. Body copy uses a neutral system sans stack. Headlines are tight and slightly condensed; metadata is uppercase, tracked, and compact.

### Brand Essence
Aurora Relay is a calm command center for people who want AI work to stay visible, inspectable, and under control.
Personality: precise, observant, composed.

### Brand Voice
Headlines are concise and operational. CTAs are specific and active. Microcopy explains state without hype.
Example lines: “Give the agent a direction.” “Your work is moving; the reasoning stays visible.”

### Wordmark & Logo
The mark is an asymmetric four-point signal prism formed by two interlocking ribbons. The wordmark uses a custom-spaced uppercase treatment with a small cyan relay notch between the words.

### Signature Brand Color
Relay Cyan: #56E0E8.
