# Aurora Relay Frontend Architecture

## Component hierarchy

`App` owns the theme and route shell. `Home` is the authenticated workspace composition, with `AuroraSidebar`, `WorkspaceHeader`, `TaskComposer`, `ActiveTaskPanel`, `ThoughtProcess`, `TaskHistory`, `ToolExplorer`, and `SettingsPanel` as focused view components. This keeps visual composition local while allowing task, tool, and settings surfaces to be reused on future routes.

## State management

Zustand owns the small cross-view state surface: current user, selected view, composer draft, task collection, active task, live event stream, and connection status. Components subscribe to narrow selectors so live events do not cause the whole shell to rerender. The store also provides a deterministic local fallback so the frontend remains explorable before the FastAPI service is connected.

## Data fetching

`client/src/lib/api.ts` contains a typed fetch wrapper for `/api/v1` and maps authentication, task, tool, and profile requests. The store calls these functions at action boundaries. The initial implementation uses native fetch to avoid coupling the static frontend to a specific query library; the API functions are shaped so React Query can be introduced without changing component contracts.

## WebSocket integration

`useTaskStream` opens the backend `/ws` endpoint when a token is available, sends a subscription message for the active task, normalizes incoming events, and reconnects with a bounded delay. If no backend is reachable, the store's local activity stream keeps the interface useful and visibly labels the connection state.

## Accessibility and failure handling

The shell uses semantic navigation, visible focus rings, labelled form controls, live regions for activity updates, keyboard-reachable buttons, and contrast-safe text over image surfaces. Error boundaries remain at the application root. Network failures become inline status copy and toast notifications rather than silent errors.

## Testing strategy

The first validation layer is TypeScript checking and a production Vite build. The UI is then reviewed at desktop and mobile breakpoints with preview screenshots. The most important user flows to test manually are composer submission, switching between views, opening task details, refreshing after auth loss, and resizing the sidebar on a narrow viewport.
